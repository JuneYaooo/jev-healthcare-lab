# 数据格式与追溯

全部 JSONL 文件均为 UTF-8，一行一条记录，以 id 关联，不依赖文件顺序。

| 文件 | 内容 |
| --- | --- |
| samples.jsonl | 完整整理题目：id、task、primary_scenario、ability_tags、language、group_id、request、gold、provenance、exposure |
| requests.jsonl | 仅 id、task、request；调用模型只发送 request 并按接口添加 model |
| answers.jsonl | 独立答案：id、gold、group_id |
| provenance.jsonl | 逐题来源版本、资源 URL/哈希、原标注位置、引用、许可、转换说明与代码哈希 |
| taxonomy.json | 八个场景和全部任务定义；本包未收录的任务不算已覆盖 |
| sources.lock.json | 仅本包来源的上游文件锁定清单 |
| manifest.json | 包内每个交付文件的 SHA-256 和字节数 |

request.state 是输入材料；questions.decision.criteria 为选项键与显示文本；gold 是选项键。provenance.locator 按来源采用 CSV 行号（含表头）、JSONL 行号、压缩包成员和标注 ID 等定位。

追溯链：id → 整理题目及答案 → provenance.locator → resource_url + version + SHA-256 → 原文件与原标注。SHA-256 用于确认版本和完整性，不等同临床答案审核。

原始全量数据不包含在本包中；需要时使用 trace 的 --fetch-source 下载该题直接依赖并校验哈希。失效链接或哈希变化会报错，不会静默换用新版本。

例：先从 samples.jsonl 取得完整 id，再运行 `python3 tools/medical_decision_release.py trace --dataset . --id '完整ID'`。
