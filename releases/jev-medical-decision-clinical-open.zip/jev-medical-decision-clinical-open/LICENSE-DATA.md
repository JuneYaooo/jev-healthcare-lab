# 数据许可与来源署名

本包是多个来源的选题合集，各题按 provenance.data_license 保留原许可；题目适配随相应来源许可提供。

开放核心包没有纳入非商业限制来源，但部分材料有相同方式共享要求；开放使用不等于无条件使用。非商业附加包不能作为开放核心包再许可。

| 来源 | 题数 | 数据许可 |
| --- | ---: | --- |
| [TrialGPT SIGIR](https://github.com/ncbi-nlp/TrialGPT) | 100 | [LicenseRef-NCBI-Public-Domain](https://github.com/ncbi-nlp/TrialGPT/blob/main/LICENSE) |
| [DDXPlus](https://doi.org/10.6084/m9.figshare.20043374) | 100 | [CC-BY-4.0](https://creativecommons.org/licenses/by/4.0/) |
| [CMB-Exam（中文病例单选子集）](https://github.com/FreedomIntelligence/CMB) | 454 | [Apache-2.0](https://www.apache.org/licenses/LICENSE-2.0) |
| [CNMLEQA-10k（中文案例分析子集）](https://doi.org/10.5281/zenodo.18951465) | 426 | [CC-BY-4.0](https://creativecommons.org/licenses/by/4.0/) |
| [CPIC curated pharmacogenomic tables](https://www.clinpgx.org/cpic) | 100 | [CC0-1.0](https://raw.githubusercontent.com/cpicpgx/cpic-data/82aa2518f1051bb2db9c42c1023a9f08db5a5f80/LICENSE.md) |
| [TCMEval-SDT](https://doi.org/10.6084/m9.figshare.27184596.v5) | 100 | [CC-BY-4.0](https://creativecommons.org/licenses/by/4.0/) |
| [MedMCQA](https://huggingface.co/datasets/openlifescienceai/medmcqa) | 2 | [Apache-2.0](https://www.apache.org/licenses/LICENSE-2.0) |
| [PrinciplismQA](https://github.com/FreedomIntelligence/PrinciplismQA) | 2 | [MIT](https://opensource.org/license/mit) |

## TrialGPT SIGIR

Jin et al., Matching Patients to Clinical Trials with Large Language Models。引用：https://github.com/ncbi-nlp/TrialGPT。

材料性质：患者题设配真实试验文件；不是实际入组结局。

本次适配：SIGIR 公开 relevance 0/1/2；0 不相关、1 可能转介、2 高度适合转介。

原声明：[trialgpt__LICENSE](sources/trialgpt/trialgpt__LICENSE)、[trialgpt__README.md](sources/trialgpt/trialgpt__README.md)。

## DDXPlus

Fansi Tchango et al. (2022)。引用：https://arxiv.org/abs/2205.09148。

材料性质：模拟器生成症状与诊断，不是实际病历。

本次适配：PATHOLOGY 为模拟主诊断；不把 differential distribution 当患者结局。

原声明：[ddxplus__README.md](sources/ddxplus/ddxplus__README.md)、[README.md](sources/ddxplus/README.md)、[figshare-metadata.json](sources/ddxplus/figshare-metadata.json)。

## CMB-Exam（中文病例单选子集）

Wang et al., CMB (NAACL 2024)。引用：https://arxiv.org/abs/2308.08833。

材料性质：中文医疗考试病例题；不是医院原始病历。只选病例决策单选题，排除 CMB-Clin 自由生成任务。

本次适配：固定 GitHub 测试题与公开更正版答案按 id 连接，并核对考试类别、科目和题型；完整保留原选项及答案。任务归属按公开规则筛选，不新增临床金标。 v0.4.0 新任务另使用官方验证和训练文件；上游训练划分明确标记为本地评测保留子集，不冒称官方测试。

原声明：[LICENSE](sources/cmb/LICENSE)、[README.md](sources/cmb/README.md)、[HF_DATA_CARD.md](sources/cmb/HF_DATA_CARD.md)。

## CNMLEQA-10k（中文案例分析子集）

Zong et al., Scientific Data (2026)。引用：https://doi.org/10.1038/s41597-026-07261-9。

材料性质：中文执业医师考试整编病例题；上游有案例/知识题型标注，不是真实就诊结果。

本次适配：只选原 question_type=案例分析的记录；沿用 opa—ope 和 answer，保留每题 source、年份与原始 UUID；没有官方训练/测试划分，不冒称官方测试。 v0.4.0 增加病例分期、病因、并发症、禁忌、护理和补液相关单选子集；沿用原答案，不把生成任务转换为自造金标。

原声明：[zenodo-metadata.json](sources/cnmleqa/zenodo-metadata.json)、[README.md](sources/cnmleqa/README.md)。

## CPIC curated pharmacogenomic tables

Clinical Pharmacogenetics Implementation Consortium (CPIC), curated database API v1, accessed 2026-10-10. Primary source: www.clinpgx.org; recommendation records retain their specific guideline URL.。引用：https://github.com/cpicpgx/cpic-data/wiki。

材料性质：CPIC 专家整理的功能到表型映射和基因结果用药建议表，不是患者病例。API 的原始响应随数据包冻结，访问日期不冒充数据库发布版本。

本次适配：功能表型题按 gene_result_lookup.phenotypeid 连接 gene_result.id，复制 result；用药题复制 recommendation_view.drugrecommendation，候选来自相同指南、药物和人群的原始建议。冲突输入和无替代选项排除，不生成临床答案。

原声明：[LICENSE.md](sources/cpic/LICENSE.md)、[api-documentation.md](sources/cpic/api-documentation.md)。

评测范围：只评价固定快照中的规则映射；不代表完整基因型检测、个体化处方或临床结局。指南会更新，应查看对应 guideline URL 的最新内容。按基因和指南分组，每组最多 5 题。

## TCMEval-SDT

Wang Z., Hao M., Peng S. et al. (2025), TCMEval-SDT。引用：https://doi.org/10.1038/s41597-025-04772-9。

材料性质：整理的经典医案、网络及医院病例材料；不是统一采集的前瞻性患者队列。

本次适配：v5 官方测试答案按病例 ID 连接；从病机多选答案机械映射候选是否入选。

原声明：[figshare-metadata.json](sources/tcmeval_sdt/figshare-metadata.json)。

评测范围：固定发布版本的上游答案；未作本项目独立临床或现行规范核验。数据许可按 Figshare 数据记录，区别于论文或仓库其他内容许可。

## MedMCQA

Pal, Umapathi and Sankarasubbu (2022)。引用：https://proceedings.mlr.press/v174/pal22a.html。

材料性质：印度医学考试题；不是患者观察队列。

本次适配：仅用官方 validation、choice_type=single；cop 的 0–3 原样映射 opa–opd。

原声明：[README.md](sources/medmcqa/README.md)。

评测范围：采用数据卡 Apache-2.0，而非代码仓库许可。仅固定范围清单病例题，未独立核验现行临床规范。

## PrinciplismQA

Hong et al. (2026)。引用：https://aclanthology.org/2026.findings-acl.1806/。

材料性质：上游模型根据医学伦理教材构造题目，经医学专家审核；不是实际临床记录。

本次适配：保留固定清单中处置选择题的原问题、选项及 correct_answer；不纳入开放式问答或原则分类题。

原声明：[README.md](sources/principlismqa/README.md)、[LICENSE](sources/principlismqa/LICENSE)。

评测范围：模型构题与筛选可能引入偏差；少量情境题只提供探索性覆盖，不能代表国际伦理共识或法律意见。
