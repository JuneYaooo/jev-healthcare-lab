### Clinical Trials for Evidence-Based Medicine in Spanish corpus version 3 

![screenshot](annot_rels_sample.png)

This repository includes the text and annotation files of the CT-EBM-SP version 3 corpus.

This is a collection of __1200 texts about clinical trials__ annotated with entities and semantic relations, and normalized to UMLS concept unique identifiers (CUIs):
- __500 abstracts__ published in medical journals available from [SciELO](https://scielo.org/es/)
- __700 clinical trials announcements__ from the [Spanish Clinical Trials Register](https://reec.aemps.es) and the [European Register of Clinical Trials (EudraCT)]([https://scielo.org/es/](https://www.clinicaltrialsregister.eu))

The repository also includes the code for the experiments on medical relation extraction and concept normalization.

Please, read the guidelines in the repository to check the entity and relation scheme and the concept normalization criteria.

## How to cite
The article describing the first version of the corpus is [available here](https://bmcmedinformdecismak.biomedcentral.com/articles/10.1186/s12911-021-01395-z).

If you use this new version and code, please, cite as follows:

```
  @article{2025,   
  title       = {Transformer-based relation extraction and concept normalization using an annotated clinical trials corpus},  
  author       = {Campillos-Llanos, Leonardo and Valverde-Mateos, Ana and Capllonch-Carrión, Adrián, and González-Quevedo, David and López-Urbán, María Rosa and Hernando-Tundidor, María Soledad and Heras-Vicente, Jónathan},   
  journal = {Under review},
  year      = {2025}
  }
```


## Contact

Leonardo Campillos-Llanos, CSIC (Spanish National Research Council)

```leonardo.campillos AT csic.es```


CLARA-MeD Project (PID2020-116001RA-C33), 2021-24

Funded by MCIN/AEI/10.13039/501100011033/, in project call: "Proyectos I+D+i Retos Investigación"

ExPlain4Health Project (PID2024-158912NB-I00), 2025-27

Funded by MCIN/AEI/10.13039/501100011033/, in project call: "Proyectos I+D+i Retos Investigación"


