# 数据许可与来源署名

本包是多个来源的选题合集，各题按 provenance.data_license 保留原许可；题目适配随相应来源许可提供。代码的 MIT 许可不覆盖第三方材料。

开放核心包没有纳入非商业限制来源，但部分材料有相同方式共享要求；开放使用不等于无条件使用。非商业附加包不能作为开放核心包再许可。

| 来源 | 题数 | 数据许可 |
| --- | ---: | --- |
| [DDI Corpus 2013](https://github.com/isegura/DDICorpus) | 100 | [CC-BY-NC-4.0](https://creativecommons.org/licenses/by-nc/4.0/) |
| [TCM-SD](https://github.com/borororo/zy-bert) | 100 | [CC-BY-NC-SA-4.0](https://creativecommons.org/licenses/by-nc-sa/4.0/) |
| [CT-EBM-SP v3](https://github.com/lcampillos/ct-ebm-sp-v3) | 858 | [CC-BY-NC-SA-4.0](https://creativecommons.org/licenses/by-nc-sa/4.0/) |
| [E3C English Layer 1](https://github.com/hltfbk/E3C-Corpus) | 385 | [CC-BY-NC (publisher does not specify version)](https://github.com/hltfbk/E3C-Corpus/blob/8196181eacd5d65828d324dcc63970c503aff5e9/README.md) |
| [CARE-Bench](https://github.com/ningkko/CARE-bench) | 100 | [CC-BY-NC-4.0](https://creativecommons.org/licenses/by-nc/4.0/) |

## DDI Corpus 2013

Herrero-Zazo, Segura-Bedmar, Martinez and Declerck (2013)。引用：https://doi.org/10.1016/j.jbi.2013.07.011。

材料性质：DrugBank / MEDLINE 文本，不是患者处方。

本次适配：沿用公开测试集药物实体对及 ddi/type 标签。

原声明：[ddi__README](sources/ddi/ddi__README)。

## TCM-SD

Ren et al. (2022)。引用：https://aclanthology.org/2022.ccl-1.80/。

材料性质：发布论文称真实临床记录；不评价疗效。

本次适配：原始 norm_syndrome；不使用病名/证型字段作为输入。

原声明：[tcm_sd__README.md](sources/tcm_sd/tcm_sd__README.md)。

## CT-EBM-SP v3

Campillos-Llanos et al.; CSIC。引用：https://github.com/lcampillos/ct-ebm-sp-v3。

材料性质：西班牙语试验注册文本与期刊摘要；不是患者就诊记录。

本次适配：使用 brat/test 原始人工属性和关系；频次与剂型关联另外使用 brat/dev，逐题保留划分。实体片段或关联目标有限选择；不导出 UMLS 术语库，不构造未标注负例。

原声明：[README.md](sources/ct_ebm_sp/README.md)、[LICENSE](sources/ct_ebm_sp/LICENSE)、[annotation.conf](sources/ct_ebm_sp/annotation.conf)。

## E3C English Layer 1

Magnini et al.; Fondazione Bruno Kessler。引用：https://e3c.fbk.eu/home。

材料性质：公开病例报道；Layer 1 人工事件与时间标注。保留各文献原作者、DOI、原文许可。

本次适配：仅官方英文测试文档；原 docTimeRel、permanence、TIMEX3 类型及 timexLink 唯一目标机械适配，不使用自动标注层。

原声明：[README.md](sources/e3c/README.md)、[train_test_split.txt](sources/e3c/train_test_split.txt)。

## CARE-Bench

CARE-Bench authors / ningkko。引用：https://arxiv.org/abs/2608.03731。

材料性质：来源约束的重构咨询轨迹；GPT-5.5 辅助构建后人工审核（发布方说明），不是原始真实分诊记录。

本次适配：只用 public_test_1 的四类 gold_label；只给当前已披露患者消息，不给后续轮次、参考回复、信息充分性和构造标签。

原声明：[README.md](sources/care_bench/README.md)。
