# Jev 医疗决策评测集 · 辅助评测 · open

本包包含 2,950 道整理题目，32 个有题任务；无需下载全量上游数据即可读取和评测。

[数据格式与追溯](FORMAT.md) · [逐题溯源示例](example-trace.json) · [数据许可与引用](LICENSE-DATA.md) · [题目](samples.jsonl) · [无答案请求](requests.jsonl) · [答案](answers.jsonl)

## 快速使用

在解压后的目录执行，Python 3.10+，仅标准库：

```bash
python3 tools/medical_decision_release.py verify --dataset .
python3 tools/medical_decision_release.py trace --dataset . --id bounded_score:medcalc:489
python3 tools/medical_decision_release.py score --dataset . --predictions predictions.jsonl --output scores.json
```

预测文件每行形如 `{"id":"完整样本ID","choice":"选项键"}`；缺失与无效回答计错，重复、未知或范围外 ID 报错。只评分本包题目：诊断来源子集合并，所有有题任务先在场景内等权，再对有分数场景等权。少于 20 题标记小样本，仍计入总分；空任务不计零分。范围和许可分包不同的汇总分不能直接比较。辅助包没有临床主分数。

A/B/C 等随题变化的选项只计算准确率和来源组结果。固定语义标签才计算 F1、召回、混淆矩阵和样本多数类基线。未实现模型调用及耗时采集。

## 读取

```python
import json
with open("requests.jsonl", encoding="utf-8") as f:
    for line in f:
        row = json.loads(line)
        request = row["request"]  # 将此对象交给模型；勿发送答案或来源标注
```

## 来源与复建

项目：[Jev Healthcare Lab](https://github.com/JuneYaooo/jev-healthcare-lab)。本包包含锁定资源清单、原许可声明和精确版本的转换/评分代码。

完整重建在项目仓库执行 `python3 scripts/medical_decision_dataset.py fetch`、`python3 scripts/medical_decision_dataset.py build`，再运行 `python3 scripts/medical_decision_release.py build`。以 release.json 的版本和源清单哈希核对，勿将不同版本成绩直接比较。

## 使用边界

这是冻结评测子集，不是训练集。用于训练会影响后续同题比较。材料包括模拟病例、考试改编、临床病例报告等，不能统称真实患者病历。答案沿用上游标注，尚未经过本项目独立医生逐题审核。

本包中 331 题的材料或片段命中过往评测，已逐题标记；通用片段可能误报。分组不一律等于患者；同来源组的题需配对或聚类分析。

模型成绩未随包生成。法律许可和来源署名以 LICENSE-DATA.md 及原声明为准。
