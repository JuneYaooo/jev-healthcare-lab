# 数据许可与来源署名

本包是多个来源的选题合集，各题按 provenance.data_license 保留原许可；题目适配随相应来源许可提供。代码的 MIT 许可不覆盖第三方材料。

开放核心包没有纳入非商业限制来源，但部分材料有相同方式共享要求；开放使用不等于无条件使用。非商业附加包不能作为开放核心包再许可。

| 来源 | 题数 | 数据许可 |
| --- | ---: | --- |
| [TCM-SD](https://github.com/borororo/zy-bert) | 100 | [CC-BY-NC-SA-4.0](https://creativecommons.org/licenses/by-nc-sa/4.0/) |
| [CARE-Bench](https://github.com/ningkko/CARE-bench) | 100 | [CC-BY-NC-4.0](https://creativecommons.org/licenses/by-nc/4.0/) |
| [PMR-Synth annotated pairs](https://huggingface.co/datasets/PortalPal-AI/PMP-Synth-AllPairs-Annotated) | 30 | [CC-BY-NC-4.0](https://creativecommons.org/licenses/by-nc/4.0/) |

## TCM-SD

Ren et al. (2022)。引用：https://aclanthology.org/2022.ccl-1.80/。

材料性质：发布论文称真实临床记录；不评价疗效。

本次适配：原始 norm_syndrome；不使用病名/证型字段作为输入。

原声明：[tcm_sd__README.md](sources/tcm_sd/tcm_sd__README.md)。

## CARE-Bench

CARE-Bench authors / ningkko。引用：https://arxiv.org/abs/2608.03731。

材料性质：来源约束的重构咨询轨迹；GPT-5.5 辅助构建后人工审核（发布方说明），不是原始真实分诊记录。

本次适配：只用 public_test_1 的四类 gold_label；只给当前已披露患者消息，不给后续轮次、参考回复、信息充分性和构造标签。

原声明：[README.md](sources/care_bench/README.md)。

## PMR-Synth annotated pairs

Gatto et al. (2026)。引用：https://arxiv.org/abs/2601.13178。

材料性质：人工合成患者消息，配对去标识病历背景；不能称为真实患者发出的消息。

本次适配：沿用 Label 字段的 Patient #1 / Patient #2；每条消息与病历最多出现一次。

原声明：[README.md](sources/pmr_synth/README.md)。

评测范围：公开 INBOX_A/B 与论文 train/test 的对应未确认；不得视为未暴露官方测试集。保留原始 inbox 标记；60 条消息至多组成 30 个不重复材料的比较，仍只来自两个收件箱。
