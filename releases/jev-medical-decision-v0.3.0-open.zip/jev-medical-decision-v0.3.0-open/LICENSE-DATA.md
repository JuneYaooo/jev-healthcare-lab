# 数据许可与来源署名

本包是多个来源的选题合集，各题按 provenance.data_license 保留原许可；题目适配随相应来源许可提供。代码的 MIT 许可不覆盖第三方材料。

开放核心包没有纳入非商业限制来源，但部分材料有相同方式共享要求；开放使用不等于无条件使用。非商业附加包不能作为开放核心包再许可。

| 来源 | 题数 | 数据许可 |
| --- | ---: | --- |
| [ACI-Bench](https://github.com/microsoft/clinical_visit_note_summarization_corpus) | 100 | [CC-BY-4.0](https://creativecommons.org/licenses/by/4.0/) |
| [MedQuAD](https://github.com/abachaa/MedQuAD) | 100 | [CC-BY-4.0](https://creativecommons.org/licenses/by/4.0/) |
| [MEDEC-MS](https://github.com/abachaa/MEDEC) | 100 | [CC-BY-4.0](https://creativecommons.org/licenses/by/4.0/) |
| [MedErrBench CN](https://github.com/congboma/MedErrBench) | 100 | [MIT](https://opensource.org/license/mit) |
| [NUBes SAMPLE-001](https://github.com/Vicomtech/NUBes-negation-uncertainty-biomedical-corpus) | 100 | [CC-BY-SA-3.0-ES](https://creativecommons.org/licenses/by-sa/3.0/es/) |
| [LongHealth](https://github.com/kbressem/LongHealth) | 100 | [Apache-2.0](https://www.apache.org/licenses/LICENSE-2.0) |
| [MedCalc-Bench GitHub test release](https://github.com/ncbi-nlp/MedCalc-Bench) | 100 | [CC-BY-SA-4.0](https://creativecommons.org/licenses/by-sa/4.0/) |
| [SciFact](https://github.com/allenai/scifact) | 100 | [CC-BY-4.0 AND ODC-By-1.0](https://github.com/allenai/scifact/blob/master/LICENSE.md) |
| [Chia](https://doi.org/10.6084/m9.figshare.11855817) | 300 | [CC-BY-4.0](https://creativecommons.org/licenses/by/4.0/) |
| [Clinical Trial Parser annotated test data](https://github.com/facebookresearch/Clinical-Trial-Parser) | 100 | [Apache-2.0](https://www.apache.org/licenses/LICENSE-2.0) |
| [TrialGPT SIGIR](https://github.com/ncbi-nlp/TrialGPT) | 100 | [LicenseRef-NCBI-Public-Domain](https://github.com/ncbi-nlp/TrialGPT/blob/main/LICENSE) |
| [DDXPlus](https://doi.org/10.6084/m9.figshare.20043374) | 100 | [CC-BY-4.0](https://creativecommons.org/licenses/by/4.0/) |
| [MACCROBAT2020](https://doi.org/10.6084/m9.figshare.9764942.v2) | 200 | [CC-BY-4.0](https://creativecommons.org/licenses/by/4.0/) |
| [CMB-Exam（中文病例单选子集）](https://github.com/FreedomIntelligence/CMB) | 127 | [Apache-2.0](https://www.apache.org/licenses/LICENSE-2.0) |
| [CNMLEQA-10k（中文案例分析子集）](https://doi.org/10.5281/zenodo.18951465) | 273 | [CC-BY-4.0](https://creativecommons.org/licenses/by/4.0/) |

## ACI-Bench

Microsoft / Yim et al. (2023)。引用：https://www.nature.com/articles/s41597-023-02487-3。

材料性质：合成就诊会话与人工文书；不是自然发生的医院记录。

本次适配：沿用人工文书的章节标题；去除标题后作分类。

原声明：[aci_bench__LICENSE](sources/aci_bench/aci_bench__LICENSE)、[LICENSE](sources/aci_bench/LICENSE)、[aci_bench__README.md](sources/aci_bench/aci_bench__README.md)、[README.md](sources/aci_bench/README.md)。

## MedQuAD

Abacha and Demner-Fushman (2019)。引用：https://doi.org/10.1016/j.jbi.2019.103217。

材料性质：NIH 旗下网站信息形成的问题；不属于真实患者问诊。

本次适配：原 XML 的 question qtype 元数据；不评价原答案临床正确性。

原声明：[LICENSE.txt](sources/medquad/LICENSE.txt)、[readme.txt](sources/medquad/readme.txt)。

## MEDEC-MS

Abacha et al. (2025)。引用：https://aclanthology.org/2025.findings-acl.1159/。

材料性质：MedQA 考试病例改编与专家错误注入；未使用 UW 受控病历。

本次适配：原始 Error Flag 与 Error Sentence ID；原文和更正文均不作模型参考答案。

原声明：[README.md](sources/medec/README.md)、[medec__README.md](sources/medec/medec__README.md)。

## MedErrBench CN

Ma et al., MedErrBench (2026)。引用：https://arxiv.org/abs/2602.05692。

材料性质：考试病例改编及专家补充，不声称全部是原始病历。

本次适配：发布方 reviewed_data_CN_test 的错误标记和句子标记。

原声明：[mederr__README.md](sources/mederr/mederr__README.md)、[mederr__LICENSE](sources/mederr/mederr__LICENSE)。

## NUBes SAMPLE-001

Lima Lopez, Perez, Cuadros and Rigau (2020)。引用：https://aclanthology.org/2020.lrec-1.708/。

材料性质：西班牙语脱敏临床句子；句子打乱，不能据文件恢复患者。

本次适配：只用双标注及仲裁的 SAMPLE-001；作用域关系映射为否定/不确定。

原声明：[nubes__LICENSE](sources/nubes/nubes__LICENSE)、[nubes__README.md](sources/nubes/nubes__README.md)。

## LongHealth

Bressem et al., LongHealth。引用：https://github.com/kbressem/LongHealth。

材料性质：20 个虚构患者；100 道题不是 100 个患者。

本次适配：沿用发布问题、五个选项和 correct 字段。

原声明：[longhealth__README.md](sources/longhealth/longhealth__README.md)、[longhealth__LICENSE](sources/longhealth/longhealth__LICENSE)。

## MedCalc-Bench GitHub test release

Khandekar et al. (2024)。引用：https://arxiv.org/abs/2406.12036。

材料性质：文献提取、生成后人工编辑、模板混合；逐题保留 Note Type。

本次适配：原测试 CSV Ground Truth Answer；完整整数范围作为候选，不由答案生成干扰项。

原声明：[README.md](sources/medcalc/README.md)、[medcalc__github_README.md](sources/medcalc/medcalc__github_README.md)。

## SciFact

Wadden et al. (2020)。引用：https://aclanthology.org/2020.emnlp-main.609/。

材料性质：科学论文摘要，不全是临床医学。

本次适配：原始 claim evidence 标签；无该文证据标注记为未标注支持或反驳。

原声明：[LICENSE.md](sources/scifact/LICENSE.md)、[README.md](sources/scifact/README.md)。

## Chia

Kury et al. (2020)。引用：https://doi.org/10.1038/s41597-020-00620-0。

材料性质：真实 Phase IV 试验入排标准；无患者临床记录。

本次适配：医学专业人员的 BRAT 实体与关系；只转换已有标签，不合成患者。

原声明：[figshare-metadata.json](sources/chia/figshare-metadata.json)。

## Clinical Trial Parser annotated test data

Tseo, Salkola, Mohamed, Kumar and Abnousi (2020)。引用：https://arxiv.org/abs/2006.07296。

材料性质：真实试验条件，公开测试文本经过规范化，数字替换为 @NUMBER。

本次适配：专业标注员 upper_bound/lower_bound；这里只判断方向，不做数值推理。

原声明：[frd__LICENSE](sources/frd/frd__LICENSE)、[frd__README.md](sources/frd/frd__README.md)、[frd__data_README.md](sources/frd/frd__data_README.md)。

## TrialGPT SIGIR

Jin et al., Matching Patients to Clinical Trials with Large Language Models。引用：https://github.com/ncbi-nlp/TrialGPT。

材料性质：患者题设配真实试验文件；不是实际入组结局。

本次适配：SIGIR 公开 relevance 0/1/2；0 不相关、1 可能转介、2 高度适合转介。

原声明：[trialgpt__LICENSE](sources/trialgpt/trialgpt__LICENSE)、[trialgpt__README.md](sources/trialgpt/trialgpt__README.md)。

## DDXPlus

Fansi Tchango et al. (2022)。引用：https://arxiv.org/abs/2205.09148。

材料性质：模拟器生成症状与诊断，不是实际病历。

本次适配：PATHOLOGY 为模拟主诊断；不把 differential distribution 当患者结局。

原声明：[ddxplus__README.md](sources/ddxplus/ddxplus__README.md)、[README.md](sources/ddxplus/README.md)、[figshare-metadata.json](sources/ddxplus/figshare-metadata.json)。

## MACCROBAT2020

Caufield et al., MACCROBAT (2019/2020)。引用：https://doi.org/10.6084/m9.figshare.c.4652765.v1。

材料性质：公开发表的临床病例报告；原病例被编辑整理，不等同医院原始 EHR。

本次适配：原始 BRAT MODIFY 关系；把事件引用解析为文本实体，只保留目标检查/药物唯一的关联。

原声明：[figshare-metadata.json](sources/maccrobat/figshare-metadata.json)。

## CMB-Exam（中文病例单选子集）

Wang et al., CMB (NAACL 2024)。引用：https://arxiv.org/abs/2308.08833。

材料性质：中文医疗考试病例题；不是医院原始病历。只选病例决策单选题，排除 CMB-Clin 自由生成任务。

本次适配：固定 GitHub 测试题与公开更正版答案按 id 连接，并核对考试类别、科目和题型；完整保留原选项及答案。任务归属按公开规则筛选，不新增临床金标。

原声明：[LICENSE](sources/cmb/LICENSE)、[README.md](sources/cmb/README.md)、[HF_DATA_CARD.md](sources/cmb/HF_DATA_CARD.md)。

## CNMLEQA-10k（中文案例分析子集）

Zong et al., Scientific Data (2026)。引用：https://doi.org/10.1038/s41597-026-07261-9。

材料性质：中文执业医师考试整编病例题；上游有案例/知识题型标注，不是真实就诊结果。

本次适配：只选原 question_type=案例分析的记录；沿用 opa—ope 和 answer，保留每题 source、年份与原始 UUID；没有官方训练/测试划分，不冒称官方测试。

原声明：[zenodo-metadata.json](sources/cnmleqa/zenodo-metadata.json)、[README.md](sources/cnmleqa/README.md)。
