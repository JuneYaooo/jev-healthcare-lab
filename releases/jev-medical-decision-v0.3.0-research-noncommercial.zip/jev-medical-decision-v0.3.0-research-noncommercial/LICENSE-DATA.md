# 数据许可与来源署名

本包是多个来源的选题合集，各题按 provenance.data_license 保留原许可；题目适配随相应来源许可提供。代码的 MIT 许可不覆盖第三方材料。

开放核心包没有纳入非商业限制来源，但部分材料有相同方式共享要求；开放使用不等于无条件使用。非商业附加包不能作为开放核心包再许可。

| 来源 | 题数 | 数据许可 |
| --- | ---: | --- |
| [DDI Corpus 2013](https://github.com/isegura/DDICorpus) | 100 | [CC-BY-NC-4.0](https://creativecommons.org/licenses/by-nc/4.0/) |
| [TCM-SD](https://github.com/borororo/zy-bert) | 100 | [CC-BY-NC-SA-4.0](https://creativecommons.org/licenses/by-nc-sa/4.0/) |

## DDI Corpus 2013

Herrero-Zazo, Segura-Bedmar, Martinez and Declerck (2013)。引用：https://doi.org/10.1016/j.jbi.2013.07.011。

材料性质：DrugBank / MEDLINE 文本，不是患者处方。

本次适配：沿用公开测试集药物实体对及 ddi/type 标签。

原声明：[ddi__README](sources/ddi/ddi__README)。

## TCM-SD

Ren et al. (2022)。引用：https://aclanthology.org/2022.ccl-1.80/。

材料性质：发布论文称真实临床记录；不评价疗效。

本次适配：原始 norm_syndrome；不使用病名/证型字段作为输入。

原声明：[tcm_sd__README.md](sources/tcm_sd/tcm_sd__README.md)。
