# 数据许可与来源署名

本包是多个来源的选题合集，各题按 provenance.data_license 保留原许可；题目适配随相应来源许可提供。代码的 MIT 许可不覆盖第三方材料。

开放核心包没有纳入非商业限制来源，但部分材料有相同方式共享要求；开放使用不等于无条件使用。非商业附加包不能作为开放核心包再许可。

| 来源 | 题数 | 数据许可 |
| --- | ---: | --- |
| [ACI-Bench](https://github.com/microsoft/clinical_visit_note_summarization_corpus) | 100 | [CC-BY-4.0](https://creativecommons.org/licenses/by/4.0/) |
| [MedQuAD](https://github.com/abachaa/MedQuAD) | 100 | [CC-BY-4.0](https://creativecommons.org/licenses/by/4.0/) |
| [MEDEC-MS](https://github.com/abachaa/MEDEC) | 100 | [CC-BY-4.0](https://creativecommons.org/licenses/by/4.0/) |
| [MedErrBench CN](https://github.com/congboma/MedErrBench) | 100 | [MIT](https://opensource.org/license/mit) |
| [NUBes SAMPLE-001](https://github.com/Vicomtech/NUBes-negation-uncertainty-biomedical-corpus) | 100 | [CC-BY-SA-3.0-ES](https://creativecommons.org/licenses/by-sa/3.0/es/) |
| [LongHealth](https://github.com/kbressem/LongHealth) | 100 | [Apache-2.0](https://www.apache.org/licenses/LICENSE-2.0) |
| [MedCalc-Bench GitHub test release](https://github.com/ncbi-nlp/MedCalc-Bench) | 100 | [CC-BY-SA-4.0](https://creativecommons.org/licenses/by-sa/4.0/) |
| [SciFact](https://github.com/allenai/scifact) | 100 | [CC-BY-4.0 AND ODC-By-1.0](https://github.com/allenai/scifact/blob/master/LICENSE.md) |
| [Chia](https://doi.org/10.6084/m9.figshare.11855817) | 300 | [CC-BY-4.0](https://creativecommons.org/licenses/by/4.0/) |
| [Clinical Trial Parser annotated test data](https://github.com/facebookresearch/Clinical-Trial-Parser) | 100 | [Apache-2.0](https://www.apache.org/licenses/LICENSE-2.0) |
| [TrialGPT SIGIR](https://github.com/ncbi-nlp/TrialGPT) | 100 | [LicenseRef-NCBI-Public-Domain](https://github.com/ncbi-nlp/TrialGPT/blob/main/LICENSE) |
| [DDXPlus](https://doi.org/10.6084/m9.figshare.20043374) | 100 | [CC-BY-4.0](https://creativecommons.org/licenses/by/4.0/) |
| [PhysioNet Challenge 2019](https://physionet.org/content/challenge-2019/1.0.0/) | 100 | [CC-BY-4.0](https://physionet.org/content/challenge-2019/view-license/1.0.0/) |
| [MACCROBAT2020](https://doi.org/10.6084/m9.figshare.9764942.v2) | 815 | [CC-BY-4.0](https://creativecommons.org/licenses/by/4.0/) |
| [CMB-Exam（中文病例单选子集）](https://github.com/FreedomIntelligence/CMB) | 395 | [Apache-2.0](https://www.apache.org/licenses/LICENSE-2.0) |
| [CNMLEQA-10k（中文案例分析子集）](https://doi.org/10.5281/zenodo.18951465) | 417 | [CC-BY-4.0](https://creativecommons.org/licenses/by/4.0/) |
| [Diabetes 130-US Hospitals for Years 1999-2008](https://archive.ics.uci.edu/dataset/296/diabetes+130-us+hospitals+for+years+1999-2008) | 100 | [CC-BY-4.0](https://creativecommons.org/licenses/by/4.0/) |
| [Post-Operative Patient](https://archive.ics.uci.edu/dataset/82/post+operative+patient) | 68 | [CC-BY-4.0](https://creativecommons.org/licenses/by/4.0/) |
| [Heart Failure Clinical Records](https://archive.ics.uci.edu/dataset/519/heart+failure+clinical+records) | 100 | [CC-BY-4.0](https://creativecommons.org/licenses/by/4.0/) |
| [Maternal Health Risk](https://archive.ics.uci.edu/dataset/863/maternal+health+risk) | 100 | [CC-BY-4.0](https://creativecommons.org/licenses/by/4.0/) |
| [MEDDOCAN / SPACCC](https://github.com/PlanTL-GOB-ES/SPACCC_MEDDOCAN) | 100 | [CC-BY-4.0](https://raw.githubusercontent.com/PlanTL-GOB-ES/SPACCC_MEDDOCAN/783a6df385c975b328c99bcffb54196a9ba4078a/LICENSE) |
| [LabQAR](https://doi.org/10.6084/m9.figshare.29189894) | 72 | [CC-BY-4.0](https://creativecommons.org/licenses/by/4.0/) |

## ACI-Bench

Microsoft / Yim et al. (2023)。引用：https://www.nature.com/articles/s41597-023-02487-3。

材料性质：合成就诊会话与人工文书；不是自然发生的医院记录。

本次适配：沿用人工文书的章节标题；去除标题后作分类。

原声明：[aci_bench__LICENSE](sources/aci_bench/aci_bench__LICENSE)、[LICENSE](sources/aci_bench/LICENSE)、[aci_bench__README.md](sources/aci_bench/aci_bench__README.md)、[README.md](sources/aci_bench/README.md)。

## MedQuAD

Abacha and Demner-Fushman (2019)。引用：https://doi.org/10.1016/j.jbi.2019.103217。

材料性质：NIH 旗下网站信息形成的问题；不属于真实患者问诊。

本次适配：原 XML 的 question qtype 元数据；不评价原答案临床正确性。

原声明：[LICENSE.txt](sources/medquad/LICENSE.txt)、[readme.txt](sources/medquad/readme.txt)。

## MEDEC-MS

Abacha et al. (2025)。引用：https://aclanthology.org/2025.findings-acl.1159/。

材料性质：MedQA 考试病例改编与专家错误注入；未使用 UW 受控病历。

本次适配：原始 Error Flag 与 Error Sentence ID；原文和更正文均不作模型参考答案。

原声明：[README.md](sources/medec/README.md)、[medec__README.md](sources/medec/medec__README.md)。

## MedErrBench CN

Ma et al., MedErrBench (2026)。引用：https://arxiv.org/abs/2602.05692。

材料性质：考试病例改编及专家补充，不声称全部是原始病历。

本次适配：发布方 reviewed_data_CN_test 的错误标记和句子标记。

原声明：[mederr__README.md](sources/mederr/mederr__README.md)、[mederr__LICENSE](sources/mederr/mederr__LICENSE)。

## NUBes SAMPLE-001

Lima Lopez, Perez, Cuadros and Rigau (2020)。引用：https://aclanthology.org/2020.lrec-1.708/。

材料性质：西班牙语脱敏临床句子；句子打乱，不能据文件恢复患者。

本次适配：只用双标注及仲裁的 SAMPLE-001；作用域关系映射为否定/不确定。

原声明：[nubes__LICENSE](sources/nubes/nubes__LICENSE)、[nubes__README.md](sources/nubes/nubes__README.md)。

## LongHealth

Bressem et al., LongHealth。引用：https://github.com/kbressem/LongHealth。

材料性质：20 个虚构患者；100 道题不是 100 个患者。

本次适配：沿用发布问题、五个选项和 correct 字段。

原声明：[longhealth__README.md](sources/longhealth/longhealth__README.md)、[longhealth__LICENSE](sources/longhealth/longhealth__LICENSE)。

## MedCalc-Bench GitHub test release

Khandekar et al. (2024)。引用：https://arxiv.org/abs/2406.12036。

材料性质：文献提取、生成后人工编辑、模板混合；逐题保留 Note Type。

本次适配：原测试 CSV Ground Truth Answer；完整整数范围作为候选，不由答案生成干扰项。

原声明：[README.md](sources/medcalc/README.md)、[medcalc__github_README.md](sources/medcalc/medcalc__github_README.md)。

## SciFact

Wadden et al. (2020)。引用：https://aclanthology.org/2020.emnlp-main.609/。

材料性质：科学论文摘要，不全是临床医学。

本次适配：原始 claim evidence 标签；无该文证据标注记为未标注支持或反驳。

原声明：[LICENSE.md](sources/scifact/LICENSE.md)、[README.md](sources/scifact/README.md)。

## Chia

Kury et al. (2020)。引用：https://doi.org/10.1038/s41597-020-00620-0。

材料性质：真实 Phase IV 试验入排标准；无患者临床记录。

本次适配：医学专业人员的 BRAT 实体与关系；只转换已有标签，不合成患者。

原声明：[figshare-metadata.json](sources/chia/figshare-metadata.json)。

## Clinical Trial Parser annotated test data

Tseo, Salkola, Mohamed, Kumar and Abnousi (2020)。引用：https://arxiv.org/abs/2006.07296。

材料性质：真实试验条件，公开测试文本经过规范化，数字替换为 @NUMBER。

本次适配：专业标注员 upper_bound/lower_bound；这里只判断方向，不做数值推理。

原声明：[frd__LICENSE](sources/frd/frd__LICENSE)、[frd__README.md](sources/frd/frd__README.md)、[frd__data_README.md](sources/frd/frd__data_README.md)。

## TrialGPT SIGIR

Jin et al., Matching Patients to Clinical Trials with Large Language Models。引用：https://github.com/ncbi-nlp/TrialGPT。

材料性质：患者题设配真实试验文件；不是实际入组结局。

本次适配：SIGIR 公开 relevance 0/1/2；0 不相关、1 可能转介、2 高度适合转介。

原声明：[trialgpt__LICENSE](sources/trialgpt/trialgpt__LICENSE)、[trialgpt__README.md](sources/trialgpt/trialgpt__README.md)。

## DDXPlus

Fansi Tchango et al. (2022)。引用：https://arxiv.org/abs/2205.09148。

材料性质：模拟器生成症状与诊断，不是实际病历。

本次适配：PATHOLOGY 为模拟主诊断；不把 differential distribution 当患者结局。

原声明：[ddxplus__README.md](sources/ddxplus/ddxplus__README.md)、[README.md](sources/ddxplus/README.md)、[figshare-metadata.json](sources/ddxplus/figshare-metadata.json)。

## PhysioNet Challenge 2019

Reyna et al. (2019), Early Prediction of Sepsis From Clinical Data: The PhysioNet/Computing in Cardiology Challenge 2019; PhysioNet v1.0.0, doi:10.13026/v64v-d857.。引用：https://doi.org/10.1097/CCM.0000000000004145。

材料性质：真实 ICU 小时记录；只使用公开训练医院 A 中按固定哈希预选的 1,000 个来源记录，非官方隐藏测试。

本次适配：原 SepsisLabel 提前 6 小时。首次 1 所在小时加 6 得到挑战定义起病小时。要求完整 ICU 第 1–12 小时，随访至起病或第 24 小时；排除起始即阳性、12 小时内起病、非法序列及随访不足。只给前 12 小时，预测 (12,24] 小时起病。

原声明：[LICENSE.txt](sources/sepsis2019/LICENSE.txt)、[source-page.html](sources/sepsis2019/source-page.html)、[preselection.json](sources/sepsis2019/preselection.json)、[selection_frame.json](sources/sepsis2019/selection_frame.json)。

评测范围：本子集仅有 11 个阳性、89 个阴性；恒答阴性准确率为 89%，应同时报告两类召回。来源是公开训练医院 A，不能对训练过该库的模型声称盲测。选择框为 1,000 例，合格 528 例（11 阳性/517 阴性）；分层抽样改变了类别比例，不用于风险校准、临床患病率或 PPV 估计。推算起病和原挑战逐小时 utility 不等价。

## MACCROBAT2020

Caufield et al., MACCROBAT (2019/2020)。引用：https://doi.org/10.6084/m9.figshare.c.4652765.v1。

材料性质：公开发表的临床病例报告；原病例被编辑整理，不等同医院原始 EHR。

本次适配：原始 BRAT MODIFY 关系；把事件引用解析为文本实体，只保留目标检查/药物唯一的关联。

原声明：[figshare-metadata.json](sources/maccrobat/figshare-metadata.json)。

## CMB-Exam（中文病例单选子集）

Wang et al., CMB (NAACL 2024)。引用：https://arxiv.org/abs/2308.08833。

材料性质：中文医疗考试病例题；不是医院原始病历。只选病例决策单选题，排除 CMB-Clin 自由生成任务。

本次适配：固定 GitHub 测试题与公开更正版答案按 id 连接，并核对考试类别、科目和题型；完整保留原选项及答案。任务归属按公开规则筛选，不新增临床金标。 v0.4.0 新任务另使用官方验证和训练文件；上游训练划分明确标记为本地评测保留子集，不冒称官方测试。

原声明：[LICENSE](sources/cmb/LICENSE)、[README.md](sources/cmb/README.md)、[HF_DATA_CARD.md](sources/cmb/HF_DATA_CARD.md)。

## CNMLEQA-10k（中文案例分析子集）

Zong et al., Scientific Data (2026)。引用：https://doi.org/10.1038/s41597-026-07261-9。

材料性质：中文执业医师考试整编病例题；上游有案例/知识题型标注，不是真实就诊结果。

本次适配：只选原 question_type=案例分析的记录；沿用 opa—ope 和 answer，保留每题 source、年份与原始 UUID；没有官方训练/测试划分，不冒称官方测试。 v0.4.0 增加病例分期、病因、并发症、禁忌、护理和补液相关单选子集；沿用原答案，不把生成任务转换为自造金标。

原声明：[zenodo-metadata.json](sources/cnmleqa/zenodo-metadata.json)、[README.md](sources/cnmleqa/README.md)。

## Diabetes 130-US Hospitals for Years 1999-2008

John Clore, Krzysztof Cios, Jon DeShazo, Beata Strack。引用：https://doi.org/10.24432/C5230J。

材料性质：The dataset represents ten years (1999-2008) of clinical care at 130 US hospitals and integrated delivery networks. Each row concerns hospital records of patients diagnosed with diabetes, who underwent laboratory, medications, and stayed up to 14 days. The goal is to determine the early readmission of the patient within 30 days of discharge.
The problem is important for the following reasons. Despite high-quality evidence showing improved clinical outcomes for diabetic patients who receive various preventive and therapeutic interventions, many patients do not receive them. This can be partially attributed to arbitrary diabetes management in hospital environments, which fail to attend to glycemic control. Failure to provide proper diabetes care not only increases the managing costs for the hospitals (as the patients are readmitted) but also impacts the morbidity and mortality of the patients, who may face complications associated with diabetes.


本次适配：按患者取首个合格住院；出院去向只保留回家 (1)；readmitted <30 为阳性，其他为未观察到 30 日内再入院。输入移除患者 ID、住院 ID 和再入院标签。

原声明：[metadata.json](sources/uci_diabetes/metadata.json)、[source-page.html](sources/uci_diabetes/source-page.html)。

## Post-Operative Patient

Sharon Summers, Linda Woolery。引用：https://doi.org/10.24432/C5DG6Q。

材料性质：Dataset of patient features

本次适配：ADM-DECS 原术后去向标签；相同输入冲突全部排除，无患者 ID，不冒称患者独立。

原声明：[metadata.json](sources/uci_postoperative/metadata.json)、[source-page.html](sources/uci_postoperative/source-page.html)。

## Heart Failure Clinical Records

Ahmad et al.; Chicco and Jurman; UCI。引用：https://doi.org/10.24432/C5Z89R。

材料性质：This dataset contains the medical records of 299 patients who had heart failure, collected during their follow-up period, where each patient profile has 13 clinical features.

本次适配：90 日死亡：time<=90 且 DEATH_EVENT=1 为阳性；time>=90 且无此前死亡为阴性；90 日前删失排除。time 与死亡标签不输入。

原声明：[metadata.json](sources/uci_heart_failure/metadata.json)、[source-page.html](sources/uci_heart_failure/source-page.html)。

## Maternal Health Risk

Marzia Ahmed。引用：https://doi.org/10.24432/C5DP5D。

材料性质：Data has been collected from different hospitals, community clinics, maternal health cares from the rural areas of Bangladesh through the IoT based risk monitoring system.

本次适配：沿用原 RiskLevel，不能当成独立结局随访；完全相同特征冲突全部排除，无患者 ID。

原声明：[metadata.json](sources/uci_maternal/metadata.json)、[source-page.html](sources/uci_maternal/source-page.html)。

## MEDDOCAN / SPACCC

Marimon et al. (2019), Automatic De-identification of Medical Texts in Spanish: the MEDDOCAN Track, Corpus, Guidelines, Methods and Evaluation of Results; SEAD / BSC / CNIO.。引用：https://ceur-ws.org/Vol-2421/MEDDOCAN_overview.pdf。

材料性质：西班牙语公开病例报告经筛选、补入合成个人信息；不能视为原始患者身份记录。

本次适配：官方 test BRAT 人工 PHI 片段标注。目标词完全落在标注片段内映射为 yes，完全不重叠映射为 no（闭世界 O 标签）；跨边界目标排除，不生成隐私标识。

原声明：[README.md](sources/meddocan/README.md)、[LICENSE](sources/meddocan/LICENSE)。

评测范围：仅评估给定词是否落入原 PHI 片段，不是整份文档脱敏召回率。负例沿用完整标注语料的闭世界假设，仍可能受到上游漏标影响。

## LabQAR

Bhasuran, Jin, Deville et al., A Curated Dataset for Question Answering on Laboratory Test Reference Ranges and Interpretation. Scientific Data (2026); Figshare 29189894 v1.。引用：https://doi.org/10.1038/s41597-026-07554-z。

材料性质：根据专家医学参考资料整理的区间与条件，不是患者记录。仅采用 Set 1 可解析且无冲突的原始范围答案。

本次适配：原 Set 1 范围答案机械映射为同检验、单位、类别的固定候选；输入附上同组原参考条目，考查条件匹配。排除同条件答案冲突、裸数值及无替代范围条目；不生成范围或不确定答案。

原声明：[LabQAR_README.md](sources/labqar/LabQAR_README.md)、[figshare-metadata.json](sources/labqar/figshare-metadata.json)。

评测范围：仅评估给定参考条目的人群、标本和条件匹配；不是独立诊疗知识或所有实验室范围的正确性。本版 72 题，未覆盖不确定和检验方法差异。
